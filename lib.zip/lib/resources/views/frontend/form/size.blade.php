<style type="text/css">
.modal .modal-dialog .modal-title{text-align:center;font-size:22px;color:#333;text-transform:uppercase;margin:0;}
.modal .modal-dialog.fit{width:600px!important}
/*cart*/
.quantity-selector {
	font-size: 0;
}
.modal-dialog{margin:0 auto}
.modal-header .close{
	position: absolute;
	right: 18px;
	background: #000;
	opacity: 1;
	color: #fff;
	width: 30px;
	height: 30px;
	top: 18px;
	padding: 0rem;
    margin: -1rem -1rem -1rem auto;
}
.content-huongdan {
    padding: 10px 15px;
    background-color: #fff;
    margin-bottom: 25px;
    border: 1px solid #e7e7e7;
}

</style>
<div class="modal-dialog modal-dialog-size" style="max-width:900px;">
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
          	<h4 class="modal-title">Cách tính size giày</h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-md-10 col-lg-10">
					<div class="content-huongdan">
						<div class="title-huongdan">Hướng dẫn cách đo chân</div>	
					</div>
					<div style="width:100%;color:#333;text-align:center">
						<img class="img-fluid" src="access/image/sizegiay.png">
					</div>
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
		</div>
		
	</div>
</div>