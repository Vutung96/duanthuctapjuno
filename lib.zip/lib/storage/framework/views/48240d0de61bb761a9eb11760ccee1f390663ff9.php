<script>
     function xoaDonHang(){
        var conf=confirm("Bạn có chắc chắn muốn xóa đơn hàng này hay không?");
        return conf;
    }
</script>

<?php $__env->startSection('main'); ?>
<?php $__env->startSection('title','Quản lý đơn hàng'); ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">           
    <div class="row">
        <ol class="breadcrumb">
              <li><a style="color: #2f2b33;" href="<?php echo e(asset('admin/home')); ?>"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
            <li>Đơn hàng</li>
        </ol>
    </div><!--/.row-->

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Quản lý đơn hàng</h1>
        </div>
    </div><!--/.row-->


    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">

                <div class="panel-body" style="position: relative;">
                    <a href="<?php echo e(asset('admin/order')); ?>" class="btn btn-primary" style="margin: 10px 0 20px 0; position: absolute;">Danh sách đơn hàng</a>
                    <table data-toggle="table" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-sort-name="name" data-sort-order="desc">
                        <thead>
                            <tr>                                
                                <th data-sortable="true">Mã đơn hàng</th>
                                <th data-sortable="true">Họ tên</th>
                                <th data-sortable="true">Email</th>
                                <th data-sortable="true">Số điện thoại</th>
                                <th data-sortable="true">Địa chỉ</th>
                                <th data-sortable="true">Ngày đặt hàng</th>
                                <th data-sortable="true">Tùy chọn</th>
                            </tr>
                        </thead>
                        <tbody>
                    
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php switch($order->oder_status): case (1): ?> <?php echo e('bg-info'); ?>  <?php break; ?> <?php case (3): ?> <?php echo e('bg-danger'); ?>  <?php break; ?> <?php case (2): ?> <?php echo e('bg-success'); ?> <?php default: ?> <?php echo e('bg-faded'); ?> <?php endswitch; ?>">
                                    <td data-checkbox="true">JUNO <?php echo e($order->oder_id); ?></td>
                                    <td data-checkbox="true"><?php echo e($order->oder_name); ?></td>
                                    <td data-checkbox="true"><?php echo e($order->oder_email); ?></td>
                                    <td data-checkbox="true"><?php echo e($order->oder_phone); ?></td>
                                    <td data-checkbox="true"><?php echo e($order->oder_address); ?></td>
                                    <td data-checkbox="true"><?php echo e($order->created_at); ?></td>
                                    <td>
                                        <a style="border: 1px,solid,#000;" href="<?php echo e(asset('admin/order/edit/'.$order->oder_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span></a>
                                        <a style="background-color: " onclick="return xoaDonHang();" href="<?php echo e(asset('admin/order/delete/'.$order->oder_id)); ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  
                </div>
                </div>
            </div>
        </div>
    </div><!--/.row-->  



</div><!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>