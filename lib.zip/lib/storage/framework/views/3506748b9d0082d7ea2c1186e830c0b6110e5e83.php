<form method="post" enctype="multipart/form-data" role="form">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">Sửa sản phẩm</div>
            <div class="panel-body">
                <div class="form-group">
                    <label>Tên sản phẩm</label>
                    <input type="text" class="form-control"  name="ten_sp" required="" value="<?php echo e($prodlist->prod_name); ?>">
                </div>
                <div class="form-group">
                    <label>Mã sản phẩm</label>
                    <input type="text" class="form-control"  name="ma_sp" required="" value="<?php echo e($prodlist->prod_code); ?>">
                </div>
                <div class="form-group">
                    <label>Giá sản phẩm</label>
                    <input type="text" class="form-control" name="gia_sp" required="" value="<?php echo e($prodlist->prod_price); ?>">
                </div>

                <div class="form-group">
                    <label>Giá khuyễn mãi</label>
                    <input type="text" class="form-control" name="khuyen_mai"  required="" value="<?php echo e($prodlist->prod_sale_price); ?>">
                </div>

                
                <div class="form-group">
                    <label>Danh mục sản phẩm</label>
                    <select name="dm_sp" class="form-control">
                        <?php $__currentLoopData = $catelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($cate->cate_id); ?>" <?php if($prodlist->prod_cate == $cate->cate_id): ?> selected <?php endif; ?>><?php echo e($cate->cate_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Trạng thái</label>
                    <select name="trang_thai" class="form-control">
                        <option value="1" <?php if($prodlist->prod_status==1): ?> selected <?php endif; ?>>Còn hàng</option>
                        <option value="2" <?php if($prodlist->prod_status==2): ?> selected <?php endif; ?>>Hết hàng</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Loại sản phẩm</label>
                    <select name="loai_sp" class="form-control">
                        <option value="Don" <?php if($prodlist->prod_type=='Don'): ?> selected <?php endif; ?>>Đơn</option>
                        <option value="Nhom" <?php if($prodlist->prod_type=='Nhom'): ?> selected <?php endif; ?>>Nhóm</option>
                        <option value="Con" <?php if($prodlist->prod_type=='Con'): ?> selected <?php endif; ?>>Sản phẩm con</option>
                    </select>
                </div>
                <div class="form-group">
                        <label>Mô tả sản phẩm</label>
                        <textarea class="form-control ckeditor" name="mo_ta_sp"><?php echo e($prodlist->prod_des); ?></textarea>                                               
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">Thuộc tính sản phẩm</div>
            <div class="panel-body">
                <div class="form-group">
                    <?php $__currentLoopData = $attlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label><?php echo e($att->att_name); ?></label>
                    <select name="value_id[]" class="select2 form-control" multiple="multiple" style="height: 36px;width: 100%;">
                        <?php $__currentLoopData = $att->value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($attvalue->att_value_id); ?>"
                                <?php for($i=0;$i<count($prodlist->value);$i++): ?>
                                    <?php if($prodlist->value[$i]->att_value_id==$attvalue->att_value_id): ?> 
                                           selected     
                                    <?php endif; ?>
                                <?php endfor; ?>
                                ><?php echo e($attvalue->att_value); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">Ảnh sản phẩm</div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="img">
                        <img width="200" src="<?php echo e(asset("storage/avatar/".$prodlist->thumbnail->img_name)); ?>" alt="">
                    </div>
                    <a style="color: #956bc0" href="" rel="thumbnail">Thay đổi ảnh đại diện</a>
                    <input type="hidden" name="prod_thumbnail" value="<?php echo e($prodlist->prod_thumbnail); ?>">
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">Thư viện ảnh</div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="gallery">
                        <?php $__currentLoopData = $prodlist->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img style="width: 50px; height: 50px" src="<?php echo e(asset("/storage/avatar/".$gallery->img_name)); ?>" alt="">
                            <input type="hidden" name="img_gallery[]" value="<?php echo e($gallery->img_id); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a style="color: #956bc0" href="" rel="gallery">Chọn ảnh</a>
                </div>
            </div>
        </div>
    </div>
    <button style="margin-left: 15px;" type="submit" class="btn btn-primary" name="submit">Sửa</button>

<?php echo e(csrf_field()); ?>

</form>