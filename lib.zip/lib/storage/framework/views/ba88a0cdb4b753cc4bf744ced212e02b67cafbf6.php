<script>
<?php if(Session::has('error')): ?>
	new PNotify({
		    title: 'Lỗi!',
		    text: '<?php echo e(session('error')); ?>',
		    type: 'error'
		});
	
<?php endif; ?>
<?php if(Session::has('success')): ?>
	new PNotify({
		    title: 'Thành công',
		    text: '<?php echo e(session('success')); ?>',
		    type: 'success'
		});
<?php endif; ?>
<?php if(Session::has('error')): ?>
	new PNotify({
		    title: 'Lỗi!',
		    text: '<?php echo e(session('error')); ?>',
		    type: 'error'
		});
	
<?php endif; ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	new PNotify({
		    title: 'Lỗi!',
		    text: '<?php echo e($error); ?>',
		    type: 'error'
		});
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>