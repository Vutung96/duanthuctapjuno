<!DOCTYPE html>
<html>
<head>
<base href="<?php echo e(asset('backend')); ?>/">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title'); ?> | Juno Shop</title>
<link href="anh/admin.png" rel="shortcut icon">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/select2.min.css" rel="stylesheet" >
<link href="css/pnotify.custom.min.css" rel="stylesheet">
<link href="css/dropzone.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</script>
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background-color: #242227;box-shadow: 0 4px 50px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(asset('admin/home')); ?>"><span>JUNOSHOP</span>Admin</a>
            <ul class="user-menu">
                <li class="dropdown pull-right">

                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg><span style="color: white;">Xin chào, <?php echo e(Auth::user()->user_name); ?></span> <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="#"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Thông tin thành viên</a></li>
                        <li><a href="#"><svg class="glyph stroked gear"><use xlink:href="#stroked-gear"></use></svg> Cài đặt</a></li>
                        <li><a href="<?php echo e(asset('logout')); ?>"><svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Đăng xuất</a></li>
                    </ul>
                </li>
            </ul>
        </div>

    </div><!-- /.container-fluid -->
</nav>

<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar" style="background: #3d3942;">
    <form role="search">
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Tìm kiếm">
        </div>
    </form>
    <ul class="nav menu">
        <li class="<?php echo e(Request::is('admin/home') ? 'active' : ''); ?>"><a href="<?php echo e(asset('admin/home')); ?>"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Trang chủ quản trị</a></li>
        <li class="<?php echo e(Request::is('admin/account') ? 'active' : ''); ?>">
            <a href="<?php echo e(asset('admin/account')); ?>">
                <span data-toggle="collapse" href="#sub-item-1"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg></span> Quản lý thành viên
            </a>
        </li>
        <li class="<?php if(Request::is('admin/product') || Request::is('admin/attribute') || Request::is('admin/category') || Request::is('admin/product/add') || Request::is('admin/attribute/add') || Request::is('admin/category/add')): ?> active <?php endif; ?> parent">
            <a href="<?php echo e(asset('admin/product')); ?>">
                <span data-toggle="collapse" href="#sub-item-2"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Quản lý sản phẩm
            </a>
            <ul class="children collapse" id="sub-item-2">
                <li>
                    <a class="children" href="<?php echo e(asset('admin/attribute')); ?> ">
                        <svg class="glyph stroked clipboard with paper"><use xlink:href="#stroked-clipboard-with-paper"/></svg> Thuộc tính sản phẩm
                    </a>
                </li>
                <li>
                    <a class="children" href="<?php echo e(asset('admin/category')); ?>">
                        <svg class="glyph stroked notepad "><use xlink:href="#stroked-notepad"/></svg> Danh mục sản phẩm
                    </a>
                </li>

            </ul>				
        </li>
        <li class="<?php echo e(Request::is('admin/gallery') ? 'active' : ''); ?>">
            <a href="<?php echo e(asset('admin/gallery')); ?>">
                <span data-toggle="collapse" href="#sub-item-3"><svg class="glyph stroked landscape"><use xlink:href="#stroked-landscape"/></svg>
</span> Thư viện ảnh
            </a>
        </li>
        <li class="<?php echo e(Request::is('admin/comment') ? 'active' : ''); ?>">
            <a href="<?php echo e(asset('admin/comment')); ?>">
                <span data-toggle="collapse" href="#sub-item-4"><svg class="glyph stroked two messages"><use xlink:href="#stroked-two-messages"/></svg></span> Quản lý bình luận
            </a>

        </li>

        <li class="<?php echo e(Request::is('admin/order') ? 'active' : ''); ?>">
            <a href="<?php echo e(asset('admin/order')); ?>">
                <span data-toggle="collapse" href="#sub-item-5"><svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
</span> Quản lý đơn hàng
            </a>
        </li>  
        <li class="<?php echo e(Request::is('admin/page') ? 'active' : ''); ?>">
            <a href="<?php echo e(asset('admin/page')); ?>">
                <span data-toggle="collapse" href="#sub-item-5"><svg class="glyph stroked app window with content"><use xlink:href="#stroked-app-window-with-content"/></svg>
</span> Quản lý page
            </a>
        </li> 

        

        <li role="presentation" class="divider"></li>
        <li><a href="<?php echo e(asset('logout')); ?>"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Đăng xuất</a></li>
    </ul>

</div><!--/.sidebar-->

<!-- Main -->
    <?php echo $__env->yieldContent('main'); ?>

        
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/chart.min.js"></script>
        <script src="js/chart-data.js"></script>
        <script src="js/easypiechart.js"></script>
        <script src="js/easypiechart-data.js"></script>
        <script src="js/bootstrap-datepicker.js"></script>  
        <script src="js/bootstrap-table.js"></script>
        <link rel="stylesheet" href="css/bootstrap-table.css"/>
        <script type="text/javascript" src="js/select2.full.min.js"></script>
        <script type="text/javascript" src="js/select2.min.js"></script>
        <script src="js/pnotify.custom.min.js"></script>
        <script src="js/dropzone.js" type="text/javascript"></script>
        <script src="js/myscript.js" type="text/javascript"></script>
        <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
        <script>
            $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });
        </script>
        <script>
            $(document).ready(function () {
                $('#avatar').on('click',function(){
                    $('#img').click();
                });

                $('#img').on('change',function(){
                    var arr = new FormData($('.form_account')['0']);
                    $.ajax({
                        url: '<?php echo e(route( 'uploadImage' )); ?>',
                        type: 'post',
                        data: arr,
                        contentType: false,
                        processData: false,
                        success: function (dt) {
                            $('#avatar').attr('src',dt.path);
                            $('input[name="user_avatar"]').val(dt.filename);
                        }
                    });
                });
            });
        </script> 
        <script>
            $('#calendar').datepicker({
            });

            !function ($) {
                $(document).on("click", "ul.nav li.parent > a > span.icon", function () {
                    $(this).find('em:first').toggleClass("glyphicon-minus");
                });
                $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
            }(window.jQuery);

            $(window).on('resize', function () {
                if ($(window).width() > 768)
                    $('#sidebar-collapse').collapse('show')
            })
            $(window).on('resize', function () {
                if ($(window).width() <= 767)
                    $('#sidebar-collapse').collapse('hide')
            })
            $(".select2").select2();
        </script> 
        <?php echo $__env->make('error.note', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
        <?php echo $__env->yieldContent('footer'); ?>

    </body>

</html>
