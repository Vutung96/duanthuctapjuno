<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductOder extends Model
{
    //
    protected $table = 'product_oder';
    protected $guarded = [];
}
